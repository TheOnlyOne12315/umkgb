===============================================================================
                       ULTIMATE MORTAL KOMBAT GB  v1.0
            a Mortal Kombat (Game Boy) rom hack by The Mortal Kombat GB guy
===============================================================================

Hey! Thanks for checking this out.

So, the Game Boy version of Mortal Kombat... we all know it. Slow, missing
stuff, half the moves didn't come out, no blood, Johnny Cage just wasn't
there. I always thought there was a decent game buried in there, so I went
in and dug it out.

The goal was never to make a perfect copy of the arcade. It was just to make
Game Boy Mortal Kombat a good game, hopefully a great one. Some stuff is
inspired by the arcade because it was cool there, some stuff is my own idea,
and the parts of the GB version that already worked stayed in.

It's a free fan project. Not made for money, not affiliated with anybody.
Please don't sell it, and please don't sell it on a reproduction cart either.
If someone charged you for this, you got ripped off.


-------------------------------------------------------------------------------
 WHAT'S NEW
-------------------------------------------------------------------------------

 * It's FAST now. The fights run way quicker, closer to Mortal Kombat II on
   the Game Boy.

 * Johnny Cage is back! Fully playable, with his own sprites and animations
   and every normal attack, plus the Green Bolt, Shadow Kick, Split Punch
   and his Decapitating Uppercut fatality.

 * Goro is playable, right from the character select. No cheat needed. If
   you play as him, he shows up in the mirror match but not again as the
   boss.

 * Reptile is hiding in here. See SECRETS below.

 * A brand new soundtrack, remade from the arcade's music: every stage has
   its own song, plus Test Your Might, Shang Tsung's boss music, the
   continue screen and more.

 * All the arcade stages (except Pit Bottom): Courtyard, Palace Gates,
   Warrior Shrine, The Pit, Throne Room and Goro's Lair, in the arcade's
   order.

 * BLOOD. Arcade-style sprays, bigger hits make bigger sprays, and it pools
   on the floor.

 * Fatalities redone to look like the arcade ones, plus a new one for Goro.
   Kano and Sub-Zero hold the heart / spine up until the battle plan, just
   like in the arcade.

 * Test Your Might after every 3 wins.

 * Special move inputs changed to the arcade ones, and they actually come
   out now.

 * Arcade-style character select layout, new title screen, the arcade
   battle plan order, "RAIDEN" spelled right, and a bunch of smaller fixes.

 * An options menu (see below). Your settings get saved.


-------------------------------------------------------------------------------
 HOW TO PATCH IT
-------------------------------------------------------------------------------

You need your own copy of the original game. I can't give you the ROM, so
please don't ask.

 The ROM you need:   Mortal Kombat (USA, Europe) (Game Boy)
   Size:             262,144 bytes (256 KB)
   CRC32:            90EB0929
   SHA-1:            59752879EFAF2F271CE4B8A9D4A455056A2985D0

 1. Get Floating IPS (Flips), or use the online ROM Patcher JS.
 2. Apply "UMKGB_V1.0.bps" to that ROM.
 3. Play the new .gb file. It ends up 512 KB, that's normal.

If the patcher complains about the checksum, your ROM is a different version
or it's been modified. Find a clean one that matches the CRC32 above.

Tested on Mesen, a real Super Game Boy and a real GBA SP.

The game now uses save memory to keep your options. Emulators handle that
by themselves (you'll get a .sav file). On a flash cart, make sure it's set
up to give the game save RAM.


-------------------------------------------------------------------------------
 CONTROLS
-------------------------------------------------------------------------------

 B ............ Punch
 A ............ Kick
 START ........ Block
 SELECT ....... Pause

That's the default (button type 1). You can change it in Options:

 Type 1:  B punch, A kick, START block, SELECT pause
 Type 2:  A punch, B kick, START block, SELECT pause
 Type 3:  B punch, A kick, SELECT block, START pause

In the move lists, "Back" means away from your opponent and "Forward" means
toward them. Tap the directions one after another; a small pause between
them is fine.


-------------------------------------------------------------------------------
 SPECIAL MOVES
-------------------------------------------------------------------------------

 KANO
   Knife Throw ............. Block (tap), Back, Forward
   Spin Attack ............. Forward, Down, Back, Up

 RAIDEN
   Lightning ............... Down, Forward, Punch
   Teleport ................ Down, Up
   Body Launch (torpedo) ... Back, Back, Forward

 LIU KANG
   Fireball ................ Forward, Forward, Punch
   Flying Kick ............. Forward, Forward, Kick

 JOHNNY CAGE
   Green Bolt .............. Back, Forward, Punch
   Shadow Kick ............. Back, Forward, Kick
   Split Punch ............. Back + Punch together (keep holding Back)
                             (doesn't work on Sonya or another Cage,
                              same as the arcade)

 SCORPION
   Spear ................... Back, Back, Punch
   Teleport Punch .......... Down, Back, Punch

 SUB-ZERO
   Iceball ................. Down, Forward, Punch
   Slide ................... Back + Punch + Kick together

 SONYA
   Energy Rings ............ Punch, Back, Punch
                             (press Back after the punch finishes)
   Teleport Punch .......... Forward, Back, Punch
   Leg Grab ................ Down + Punch + Kick together

 GORO
   Fireball ................ Back, Forward, Punch


-------------------------------------------------------------------------------
 FATALITIES
-------------------------------------------------------------------------------

Only when the screen says FINISH HIM / FINISH HER.

 KANO ........ Heart Rip ............... Back, Down, Forward, Punch
 RAIDEN ...... Electrocution ........... Forward, Back, Back, Back, Punch
 LIU KANG .... Cartwheel Uppercut ...... Forward, Down, Back, Up
 JOHNNY CAGE . Decapitating Uppercut ... Forward, Forward, Forward, Punch
 SCORPION .... Toasty .................. Block, Up
 SUB-ZERO .... Spine Rip ............... Forward, Down, Forward, Punch
 SONYA ....... Kiss of Fire ............ Forward, Forward, Back, Back, Block
 GORO ........ Head-Exploding Fireball . Back, Back, Forward, Punch

Kano, Raiden, Sub-Zero and Johnny Cage walk up to the opponent by themselves
if they're too far away. Goro's works from anywhere on screen.


-------------------------------------------------------------------------------
 SECRETS
-------------------------------------------------------------------------------

 REPTILE
   In a one-player game, on The Pit (the first stage), win both rounds
   with a flawless victory and finish with a fatality. Reptile shows up
   next on The Pit. Beat him for 10,000,000 points. Once per game.

 REPTILE CHEAT
   Hold SELECT while confirming your fighter, and your first fight is
   against Reptile.


-------------------------------------------------------------------------------
 TEST YOUR MIGHT
-------------------------------------------------------------------------------

Comes up after every 3 matches you win. Mash A and B to fill the meter (it
drains, so keep going), then hit START to strike before time runs out.
The blocks go wood, stone, steel, ruby, diamond. You only move up after
breaking one.


-------------------------------------------------------------------------------
 OPTIONS
-------------------------------------------------------------------------------

Press START on the title screen, then pick OPTIONS. Up/Down picks a line,
Left/Right changes it, B goes back. Everything gets saved.

 DIFFICULTY .. V. Easy / Easy / Normal / Hard / V. Hard
 BUTTONS ..... Type 1 / 2 / 3 (see CONTROLS)
 BLOOD ....... On / Off
 ROUNDS ...... 1 / 3 / 5 (best of)
 TIMER ....... On / Off
 CONTINUES ... 3 / 6 / 9 / Infinite
 MUSIC ....... Sound test: press A to play a song
 VOICE ....... Sound test: press A to hear a voice clip


-------------------------------------------------------------------------------
 KNOWN STUFF
-------------------------------------------------------------------------------

 * Link cable two-player isn't supported.
 * If you sit there and nobody lands a single hit all round, you lose
   when time runs out. That's how the original game works too.
 * Turning Blood off removes the sprays and pools. The fatalities still
   look like fatalities.

Found a bug? Let me know and tell me what you were doing when it happened.


-------------------------------------------------------------------------------
 CREDITS
-------------------------------------------------------------------------------

 Hack by ............... The Mortal Kombat GB guy

 Original Game Boy game  Probe Software
 Mortal Kombat ......... (c) 1992 Midway

 Music driver .......... hUGEDriver / hUGETracker by SuperDisk
 Tools ................. RGBDS, mgbdis, Mesen

Mortal Kombat belongs to its owners. This is an unofficial, non-profit fan
project. It's free, and it's not for sale in any form.

Have fun, and... FIGHT!
===============================================================================
